void func(void);
